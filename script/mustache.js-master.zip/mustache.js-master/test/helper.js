var chai = require('chai');
assert = chai.assert;
chai.should();
Mustache = require('../mustache');
