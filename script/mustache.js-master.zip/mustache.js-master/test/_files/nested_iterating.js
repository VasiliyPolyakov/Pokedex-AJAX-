({
  inner: [{
    foo: 'foo',
    inner: [{
      bar: 'bar'
    }]
  }]
})
